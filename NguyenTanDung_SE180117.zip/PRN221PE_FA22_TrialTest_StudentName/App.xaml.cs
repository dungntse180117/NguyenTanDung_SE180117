﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace PRN221PE_FA22_TrialTest_StudentName_
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
